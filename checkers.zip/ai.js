class AI extends Player {
  
}