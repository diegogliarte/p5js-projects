class Player {
  constructor() {
    
  } 
  
  gotEaten() {
    this.checkers--
  }
}